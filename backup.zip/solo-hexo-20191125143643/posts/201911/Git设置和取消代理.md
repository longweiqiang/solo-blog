title: Git 设置和取消代理
date: '2019-11-12 14:30:24'
updated: '2019-11-12 14:30:24'
tags: [技巧]
permalink: /articles/2019/11/12/1573540224417.html
---
---
title: Git 设置和取消代理
date: 2019-08-29 20:57:56
tags: 技巧
categories:
- Git
toc: true
---
##### 局部配置：

* git clone 使用 http.proxy 克隆项目
    *  git clone -c http.proxy=http://127.0.0.1:1080 https://github.com/longweiqiang/MediaCtrl.git
    *  git clone -c https.proxy=http://127.0.0.1:1080 https://github.com/longweiqiang/MediaCtrl.git

##### 全局配置：

* 全局配置Git
    *  git config --global https.proxy http://127.0.0.1:1080
    *  git config --global https.proxy https://127.0.0.1:1080    
* 取消代理
    *  git config --global --unset http.proxy
    *  git config --global --unset https.proxy    

  
##### 针对GitHub：

* 只对github.com
    *  git config --global http.https://github.com.proxy http://127.0.0.1:1080
    *  git config --global http.https://github.com.proxy https://127.0.0.1:1080    
* 取消代理
    *  git config --global --unset http.https://github.com.proxy)    


> http://www.afox.cc/archives/404
> https://gist.github.com/laispace/666dd7b27e9116faece6
